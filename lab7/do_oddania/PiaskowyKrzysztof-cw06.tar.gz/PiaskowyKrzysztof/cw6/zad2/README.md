Aby skompilować projekt i uruchomić testy należy uruchomić polecenie:
>./make
Następnie uruchomić serwer poleceniem:
>./server
Następnie w osobnych oknach konsoli uruchomić klientów:
>./client