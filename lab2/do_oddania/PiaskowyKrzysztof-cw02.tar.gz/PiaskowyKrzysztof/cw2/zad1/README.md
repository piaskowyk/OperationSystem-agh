Aby skompilować, uruchomić program, przeprowadzić testy i wygenerować plik z raportem należy uruchomić plik run.sh
>./run.sh
