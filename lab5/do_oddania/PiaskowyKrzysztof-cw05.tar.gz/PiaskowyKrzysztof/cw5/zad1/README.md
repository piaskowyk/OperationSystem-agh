Aby skompilować projekt i uruchomić testy należy uruchomić polecenie:
>./run.sh