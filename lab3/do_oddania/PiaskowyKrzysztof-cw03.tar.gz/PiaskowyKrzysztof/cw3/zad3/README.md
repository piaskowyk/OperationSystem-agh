Aby skompilować, uruchomić program, przeprowadzić testy należy uruchomić plik run.sh
>./run.sh
