Aby skompilować i uruchomić program w obu wariantach należy uruchomić plik run1.sh
>./run.sh