#ifndef LAB9_UTILS_H
#define LAB9_UTILS_H

#define WAIT 0
#define IN_CARRIAGE 1

long getTimestamp();
void printErrorMessage(const char * message, int type);

#endif //LAB9_UTILS_H
