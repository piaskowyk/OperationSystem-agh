Aby skompilować projekt należy uruchomić polecenie:
>make

Następnie aby uruchomić program w wersji A należy uruchomić:
>./main1

Następnie aby uruchomić program w wersji B - z procesem potomnym należy uruchomić:
>./main2