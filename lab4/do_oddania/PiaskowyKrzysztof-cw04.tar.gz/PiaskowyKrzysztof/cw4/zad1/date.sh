#!/usr/bin/env bash

while [ 1 ]
do
  date
  sleep 1
done