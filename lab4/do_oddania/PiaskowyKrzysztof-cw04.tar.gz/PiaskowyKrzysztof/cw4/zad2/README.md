Aby przzygotować srodowisko do przeprowadzenia testów należy uzyć skryptu:
>./run.sh

Aby skompilować projekt należy uruchomić:
>make

Następnie uruchomić program main z parametrem wejściowym:
>./main list.txt
