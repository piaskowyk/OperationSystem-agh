Aby przygotować srodowisko do przeprowadzenia testów i uruchomić program należy uzyć skryptu:
>./run.sh